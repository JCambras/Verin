import { execFileSync } from "node:child_process";
import { collectTreeFacts, e5ReviewBudget } from "../../enforcement/rules-tree.mjs";

const git = (...args) => execFileSync("git", args, { encoding: "utf8" }).trim();
const input = { eventName: "pull_request", baseSha: git("rev-parse", "origin/generation-4"), headSha: git("rev-parse", "HEAD"), declaredSliceClass: "core-semantics/record" };
const facts = collectTreeFacts(input);
const G = facts.changed.filter((item) => facts.regen[item.path]?.reproduced && facts.regen[item.path]?.summaryExists && facts.regen[item.path]?.summaryLines <= 40);
const B = facts.changed.filter((item) => item.binary && !G.includes(item));
const H = facts.changed.filter((item) => item.exists && !item.binary && !G.includes(item));
const seamModules = ["enforcement/contract.mjs", "src/access/context.ts", "src/evidence/bundle.ts", "src/policy/registry.ts", "src/decision/outcome.ts", "src/record/decision-record.ts"];
const hLines = H.reduce((sum, item) => sum + item.added, 0);
const owners = new Set(facts.changed.map((item) => /^(enforcement\/|\.github\/|docs\/|CONSTITUTION\.md|README\.md|DECISIONS\.md)/.test(item.path) ? "enforcement-contract" : item.path.includes("/") ? item.path.split("/")[0] : "repository-cluster")).size;
const seamSymbols = seamModules.flatMap((path) => facts.diffAdded[path] ?? []).filter((line) => /^export\s/.test(line)).length;
const dbObjects = Object.entries(facts.diffAdded).filter(([path]) => path.endsWith(".sql")).flatMap(([, lines]) => lines).filter((line) => /^\s*CREATE\s+(TABLE|INDEX|VIEW|SEQUENCE|TRIGGER|FUNCTION)/i.test(line)).length;
const measures = { base: input.baseSha, head: input.headSha, bucketHReviewableTextLines: hLines, filesTouched: facts.changed.length, canonicalOwnersTouched: owners, newPublicSeamSymbols: seamSymbols, newDatabaseObjects: dbObjects, newRuntimeDependencies: facts.deps?.runtimeAdded?.length ?? 0, newDevelopmentDependencies: facts.deps?.devAdded?.length ?? 0, bucketGFiles: G.length, bucketGBytes: G.reduce((sum, item) => sum + item.bytes, 0), bucketBFiles: B.length, bucketBBytes: B.reduce((sum, item) => sum + item.bytes, 0), reviewSurfaceMinutes: Math.round(hLines / 8 + B.length / 2), bucketHPaths: H.map((item) => item.path), bucketGPaths: G.map((item) => item.path), bucketBPaths: B.map((item) => item.path) };
console.log(JSON.stringify(measures, null, 2));
const violations = e5ReviewBudget({ ...input, ...facts });
console.log(violations.length ? JSON.stringify(violations, null, 2) : "E5 PASS");
if (violations.length) process.exitCode = 1;
