import { readFileSync, writeFileSync } from "node:fs";

const [arm, path] = process.argv.slice(2);
const ev = JSON.parse(readFileSync(path, "utf8"));
const [kind, op] = arm.split(":");
let mutation;
const graphNode = () => ev.graph.find((node) => node.op === op);
if (kind === "span" || kind === "log") {
  const key = `${kind}s`;
  const node = graphNode();
  const index = ev.emissions[key].findIndex((item) => item.node === node.node);
  mutation = { removed: ev.emissions[key].splice(index, 1)[0] };
} else if (kind === "metric") {
  const row = ev.registry.find((item) => item.id === op);
  const name = ev.namingPattern.replace("{id}", op) + "." + row.metric;
  const removed = ev.emissions.metrics.filter((item) => item.name === name);
  ev.emissions.metrics = ev.emissions.metrics.filter((item) => item.name !== name);
  mutation = { removed };
} else if (kind === "correlation") {
  const node = graphNode();
  mutation = { before: node.correlation };
  node.correlation = { kind: node.correlation.kind === "RequestCorrelation" ? "DecisionCorrelation" : "RequestCorrelation", fields: node.correlation.fields };
  mutation.after = node.correlation;
} else if (kind === "registry-definition" || kind === "admission-definition") {
  const list = kind === "registry-definition" ? ev.registry : ev.admission;
  const row = list.find((item) => item.id === op);
  const definition = kind === "registry-definition" ? row.semanticEffect : row.constructedDefinition;
  mutation = { before: definition.canonicalSql };
  definition.canonicalSql += " /* exact-definition-mutation */";
  mutation.after = definition.canonicalSql;
} else if (kind === "raw") {
  const index = ev.rawExecutions.findIndex((item) => item.op === op);
  mutation = { removed: ev.rawExecutions.splice(index, 1)[0] };
} else if (kind === "borrow") {
  const row = ev.rawExecutions.find((item) => item.op === op);
  const donor = ev.rawExecutions.find((item) => item.op !== op);
  mutation = { before: row.semanticEffectId, after: donor.semanticEffectId };
  row.semanticEffectId = donor.semanticEffectId;
} else if (kind === "unregistered") {
  const donor = ev.graph[0];
  const added = { ...donor, node: "n-unregistered-p6aii", op: "decisionRecord.unregistered", gatewayEntry: "enterUnregisteredP6aii" };
  ev.graph.push(added);
  mutation = { added };
} else if (kind === "unexercised") {
  const source = ev.registry.find((item) => item.id === "decisionRecord.list");
  const added = { ...source, id: "decisionRecord.unexercised", gatewayEntry: "enterUnexercisedP6aii" };
  ev.registry.push(added);
  ev.admission.push({ id: added.id, gatewayEntry: added.gatewayEntry });
  mutation = { added };
} else throw new Error(`unknown mutation arm '${arm}'`);
console.log(`exact-mutated-bytes=${JSON.stringify(mutation)}`);
writeFileSync(path, JSON.stringify(ev, null, 2) + "\n");
