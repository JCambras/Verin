import { copyFileSync, readFileSync, writeFileSync } from "node:fs";

const mode = process.argv[2];
const path = "src/record/decision-record.ts";
const backup = `test-results/pr6aii-evidence/decision-record-${mode}.backup`;
copyFileSync(path, backup);
const source = readFileSync(path, "utf8");
let before;
let after;
if (mode === "property") {
  before = `    async verify() {\n      return (await verifyStoredChain(c, grant)).verification;\n    },`;
  after = `    async verify() {\n      return { ok: true, through: decisionId, entryCount: 1, headHash: "dlh.v1:${"0".repeat(64)}", continuityManifest: "lcm.v1:${"0".repeat(64)}", rebuiltProjection: [] };\n    },`;
  if (!source.includes(before)) throw new Error("property-verifier subject not found exactly once");
  writeFileSync(path, source.replace(before, after));
} else if (mode === "structural") {
  const start = source.indexOf("async function verifyStoredChain(");
  const firstLineEnd = source.indexOf("\n", start);
  const bodyOpen = source.lastIndexOf("{", firstLineEnd);
  const endMarker = "\n}\n\nfunction createDecisionRecord";
  const bodyClose = source.indexOf(endMarker, bodyOpen) + 2;
  if (start < 0 || bodyOpen < 0 || bodyClose < 2) throw new Error("whole verifier subject was not found exactly");
  before = source.slice(bodyOpen, bodyClose);
  after = `{\n  return { verification: { ok: true, through: \`d\${c.fields.decisionId.value}\`, entryCount: 0, headHash: "dlh.v1:${"0".repeat(64)}", continuityManifest: "lcm.v1:${"0".repeat(64)}", rebuiltProjection: [] }, records: new Map() };\n}`;
  writeFileSync(path, source.slice(0, bodyOpen) + after + source.slice(bodyClose));
} else throw new Error(`unknown verifier mutation '${mode}'`);
console.log(`exact-original-bytes=${JSON.stringify(before)}`);
console.log(`exact-mutated-bytes=${JSON.stringify(after)}`);
console.log(`backup=${backup}`);
