# PR-6a-ii evidence index

Scope: the bounded record/load/verify half of PR-6a. It lands the pre-identity list and head reads,
the RequestCorrelation to DecisionCorrelation transition only after exact stored outcome bytes resolve
a real identity, record load, whole-chain and anchor verification, projection rebuild, canonical temporal
reads, and the authenticated examiner record and chain-verification surfaces.

## Exact subject and store

- Base: `76d4c766343465b1b9cb656a77f01a11c1298c22`.
- Operative head: `a800563885db66ee1840f42f9771a7dc27732419`.
- Read-only oracle head: `5542c99989fc7cec0b6e94851797b6ca3ad490a9`.
- Dedicated container: `postgres:18.6@sha256:06cad38a5d9f5d24b4d83d86def30795d5e4b757fedbf5281172b576dedcd941`
  on host port `55681`, never the default port. `green-control.txt` records its exact container id.
- `claims.txt` begins with an empty tracked status, an empty merge-base result against `origin/main`,
  the nine changed product paths, both deterministic regenerations and all ten new E16 rows.

## Operative records

- `green-control.txt` - fresh container; bootstrap, migration plus idempotent migration, seed, a
  pre-browser continuity-authorization count of zero, lint, format, denied-network production build,
  22 browser tests with Axe, two consecutive 65-test runs on the same store, the five-test pure closure,
  both deterministic byte comparisons and an empty tracked status at both ends. This is the N1 and N2
  control: the record tests rerun, and the browser fixture does not depend on Vitest creating an
  authorization row first.
- `semgrep-report.json`, `semgrep.txt`, `enforcement-final.txt`, `measure-e5.mjs` and
  `e5-measurement.txt` - the pinned scanner reports zero findings; E1-E16 and the proof-log check all
  pass over the true base-to-evidence-head range. The committed E5 collector measures H 900, 13 files,
  2 canonical owners, 2 public seam symbols, 0 database objects, 0 dependencies, G 0 files / 0 bytes,
  B 3 files / 4,276,935 bytes and 114 review minutes. H is exactly the hard ceiling and review time is
  above preferred but below hard; no further product line is available in this unit.
- `record-battery-source.txt`, `append-precondition-source.txt`, `whole-verifier-source.txt` and
  `store-claims.txt` - exact committed source and store results behind N3 and the record battery. The
  fabricated anchor over an empty ledger is refused as `anchor-present-ledger-empty` by both pre-identity
  head resolution and append. Append also requires the anchor maximum row, exact head hash and one
  sequence-zero genesis. Whole verification names payload rewrite, broken link and sequence gap at
  sequence 2, terminal deletion through the anchor mismatch, every source-class byte mutation, and
  rebuilds the projection. The restored store has five contiguous rows, one genesis, four projections,
  zero broken links and an anchor equal to the ledger head.
- `verifier-property-control.txt` and `verifier-property-mutation.txt` - the exact clean `pnpm test`
  control passes 65 tests; replacing the public verifier with exact `ok: true` bytes makes the payload
  rewrite arm fail because verified was returned instead of `payload-rewritten` at sequence 2. The source
  bytes are restored exactly.
- `verifier-structural-control.txt`, `verifier-structural-mutation.txt` and
  `verifier-structural-restore.txt` - the separately invocable structural companion passes clean, fails
  when the whole verifier body is replaced by the recorded exact `ok: true` bytes, and passes after exact
  restoration. The property and structural jaws therefore fail independently.
- `e16-capture.json`, `check-e16.mjs`, `mutate-e16.mjs`, `run-e16-arm.sh` and the 58 `e16-*.txt`
  records - all ten added operations have one clean control before each exact mutation, a failing checker
  with the operation and direction named, and a passing exact restore. The arms cover span, log, metric
  and correlation for every row; registry definition, independently constructed admission definition,
  raw execution and borrowed semantic identity for all four prepared reads; plus unregistered and
  unexercised rows.
- `pr6aii-examiner.png`, `pr6aii-examiner-print.pdf`, `pdf-render/page-1.png` and
  `screen-inspection.txt` - the full browser capture, the one-page Letter print artifact, its Poppler
  render, hashes, dimensions, Axe result and visual inspection. The examiner shows exact identities,
  policy basis, evidence and producer provenance, sequence, chain state and the demonstration label.

## Historical records

- `HISTORICAL-green-control-head72cd.txt` - the first fresh run found an order-dependent test flaw: if
  the arbitrarily selected outcome source was the current head, the correct pre-identity refusal happened
  before the whole verifier could report sequence and full identity. The committed test deterministically
  selects a non-head outcome for that whole-verifier arm.
- `HISTORICAL-green-control-head1d24.txt` - a green run before the verifier companion was split into its
  own independently invocable test. `green-control.txt` is the operative replacement at the final
  implementation head.
- `HISTORICAL-e16-zsh-unsplit-list.txt` - a superseded evidence-driver attempt in which the shell treated
  a quoted operation list as one value. It made no source mutation. All 58 operative E16 files replace it.
- `HISTORICAL-enforcement-no-semgrep.txt` - the first true-range enforcement attempt omitted the pinned
  scanner report and E14 correctly refused it. `semgrep-report.json` and `enforcement-final.txt` are the
  operative same-head replacement.

## Claim boundary

This unit claims TAMPER EVIDENCE within the stated threat boundary: application privilege, owner guards,
exact source identities, canonical envelopes, links, projection comparison and the in-database anchor.
A fully compromised database administrator can recompute a self-consistent database while there is no
authenticated latest-head anchor outside it. No absolute tamper-proof claim is made.

The continuity rows in the tests and browser are explicit fixtures whose bytes say they are not a product
signature. This unit performs no signing and makes no product-authorization claim. PR-6b still owns
historical replay and conformance; PR-6c owns the product-owner-authorized continuity boundary.
