# Review gallery - every bucket-B artifact, indexed (CONSTITUTION.md, the review budget)

One row per binary or captured-evidence artifact: path, SHA-256, byte size, authorship or capture
command, purpose, and the reviewer's inspection command.

| Path | SHA-256 | Bytes | Authorship / capture | Purpose | Inspect |
|---|---|---:|---|---|---|
| `src/app/fonts/GeistVF.woff2` | `46525b05bbf4527d263f8624ca7024c7d0dce3c64430267d30c31c6dd3821e4d` | 58512 | Vercel's Geist variable font, extracted from npm `geist@1.5.1` `package/dist/fonts/geist-sans/Geist-Variable.woff2` (`npm pack geist@1.5.1`) | self-hosted `next/font/local` typeface; `next/font/google` is forbidden (prompt 2 5A) | `shasum -a 256` and load any page |
| `docs/evidence/pr2a-signin.png` | `e90592e97527394bfebc528eb0dcd010d858c91cdebc51019214f15940d0e574` | 16248 | Playwright screenshot at 1280x800 from `src/e2e/app.e2e.ts` (URL and loaded-state marker asserted first) | section 9: the sign-in surface as shipped | open the file; re-capture with `pnpm e2e` |
| `docs/evidence/pr2a-shell.png` | `1fd9b21132cf0d0a8cea1ea1c15073c300002d3272147d52f80733f52c172454` | 33853 | Playwright screenshot at 1280x800 from `src/e2e/app.e2e.ts`, signed in as the seeded advisor | section 9: the honest empty shell PR-2a lands on (the split's user-visible result) | open the file; re-capture with `pnpm e2e` |
| `docs/evidence/pr2a-transcripts.tar.gz` | `e45d4752b30680b9144012c14c73f9e31ba1c386f20c75329da8d36524cba026` | 8026 | `tar -czf` over the PR-2a mutation and proof transcripts (one captured-evidence bundle per PR, prompt 2 section 7) | every raw transcript behind `docs/proof-log.md`'s PR-2a entries: M-B, M-D, M-E, M-F, M-G, the collector-sharpening proofs, pin currency, migration preflight, and the restored green run | `tar -tzf`, then `tar -xzf` and read |
