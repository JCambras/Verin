# Generation-4 enforcement proof log

One entry per rule (`M-E1..M-E16`) plus the named vacuity entries (`M-V1..M-V3`): each records the injected
violation, the exact failure output, and the revert. A rule with no entry is an unproven rule; the blocking
job fails unless the mapping is total in both directions. Mutations run in disposable local clones against
real repository state; no mutation writes to any remote.

## M-E1 (rule E1)
- Injected: in a disposable clone of this PR's tree with the real `origin/main` fetched,
  `git merge origin/main --allow-unrelated-histories -X ours`, then `node enforcement/run.mjs` under a
  push-context environment.
- Observed (exit 1): `E1 FAIL 644938fd628e7bdd5842c5b7941b0aba0b1d69ab - generation-4 shares history with
  origin/main: merge-base 644938fd628e7bdd5842c5b7941b0aba0b1d69ab`.
- Reverted: `git reset --hard HEAD^`; clone discarded; the shipped tree never carried the merge.

## M-E2 (rule E2)
- Subject: the real platform event payload of this stack's own pull request (PR-1a), captured from the
  blocking job's `cat "$GITHUB_EVENT_PATH"` step of that PR's first CI run. Why this subject: the
  platform-supplied base ref is the entire input; a genuinely mistargeted PR would be the violation itself,
  and creating a second repository is a network write section 3 forbids. This limitation is recorded here
  rather than smoothed.
- Captured: run 32402570676's payload for PR #46 - event `pull_request`, `base.ref: generation-4`,
  `base.sha: 71ef1955c3f65710ab5010832a67f27a2aa76cfe`, `head.ref: fm/gen4-pr-1a`.
- Arm 1, the real payload unaltered, through the shipped stack: `E2 PASS`.
- Arm 2, the same real payload with `base.ref` set to `main` (exit 1): `E2 FAIL base.ref - this pull
  request targets 'main', not generation-4`.
- Arm 3, the same real payload with the base ref deleted (exit 1): `E2 FAIL base.ref - pull_request
  payload carries no base ref; a missing field is not agreement; failing closed`.
- Reverted: the altered copies were temporary files; the shipped rule and the captured payload are unchanged.

## M-E3 (rule E3)
- Subject: the real API answer for this repository (`GET /repos/JCambras/Verin`, `default_branch: main`).
  The default branch is never actually changed to test this rule: DC-6 reserves that to the captain.
- Arm 1, real answer through the shipped stack: `E3 PASS`.
- Arm 2, the same real answer with the field set to `generation-4` (exit 1): `E3 FAIL default-branch - the
  repository default branch is 'generation-4', expected 'main'`.
- Arm 3, no credential, so the query genuinely fails (exit 1): `E3 FAIL default-branch - the repository
  default branch could not be read (no credential (GITHUB_TOKEN unset); refusing an unauthenticated read);
  an unanswered question is never treated as 'main'; failing closed`.
- Reverted: altered copy was a temporary file; nothing shipped changed.

## M-E4 (rule E4)
- Injected: a pull-request payload declaring two seam ids, through the shipped stack (exit 1):
  `E4 FAIL pr-body - more than one declared seam id: Gen4EnforcementContract, AccessContext`.
- Injected: a declared id not in `CONSTITUTION.md`'s closed roadmap list (exit 1): `E4 FAIL pr-body -
  declared seam id 'NotARatifiedSeam' is not in CONSTITUTION.md's closed roadmap list`.
- Reverted: payloads were temporary files; the closed list in `CONSTITUTION.md` is unchanged.

## M-E5 (rule E5)
All eight subcases ran in a disposable clone as simulated pull requests against the shipped stack, each
injected on a detached head and discarded. Exact failure lines (exit 1 in every failing arm):
1. Mixed overflow - a qualifying 40-line registered generated artifact plus a 401-line hand file:
   `E5 FAIL Bucket H, reviewable text lines - ... measured 415 exceeds hard ceiling 400` while printing
   `gen.txt - bucket G, added 40 lines`, proving the generated file neither counts toward nor conceals H.
2. A hand-authored runbook alone: `... measured 401 exceeds hard ceiling 400`, with
   `docs/runbook-restore.md - bucket H, added 401 lines`.
3. A hand-authored fixture, snapshot, and evidence manifest, one at a time: each
   `E5 FAIL Bucket H ... measured 401 exceeds hard ceiling 400`.
4. Generated-only overflow: 17 registered reproducing artifacts -> `Bucket G ... 17 artifacts exceeds hard
   ceiling 16`; separately two 4.5 MB artifacts -> `9437186 gross bytes exceeds hard ceiling 8 MB`.
5. A generated text artifact hand-edited by one byte: `bucket-G artifact failed its qualification
   (reproduced=false ...) reclassified to H`, then `measured 514 exceeds hard ceiling 400` counting its 500
   lines in H - both failures in one run.
6. A generated binary with broken regeneration: reclassified to B, never a line count; nine crossed
   `9 artifacts exceeds hard ceiling 8`, and a 7 MB one crossed `7340048 gross bytes exceeds hard ceiling
   6 MB` with `img-big.bin - bucket B, added 0 lines, 7340048 bytes`.
7. A hand-authored font with a gallery row: `E5 PASS` (enters B immediately); removing its gallery row:
   `bucket-B artifact has no review-gallery row (path + SHA-256)`; nine hand binaries and a 7 MB capture
   then crossed the B count and byte ceilings for the intended reasons.
8. Binary-only: nine gallery-listed screenshots -> B count failure; two 3.5 MB screenshots -> B byte
   failure; two small screenshots with the gallery deleted ->
   `bucket-B artifact has no review-gallery row` for each, under both ceilings.
- Reverted: every mutation was a detached-head commit in the clone; the branch never moved.

## M-E6 (rule E6)
- Injected: `enforcement/orphan.mjs` exporting `orphanHelper` with no caller (exit 1):
  `E6 FAIL enforcement/orphan.mjs - new exported symbol 'orphanHelper' has no non-test caller reachable
  from a live entry path`.
- Then a test-only caller (`orphan.test.mjs`): the same failure - a test caller is not reachability.
- Then wired into the live runner entry: `E6 PASS`. Reverted: detached-head commits, discarded.

## M-E7 (rule E7)
- Injected: a real surface `src/ui/balance-card.tsx` rendering `{account.balance}` bare (exit 1):
  `E7 FAIL src/ui/balance-card.tsx - metric-class render without provenance (no source/asOf):
  <span>{account.balance}</span>` - and the plain `{household.name}` on the same surface passed untouched,
  proving the rule does not fire on every render. Reverted.

## M-E8 (rule E8)
- Injected: `["E99", () => []]` - an always-PASS check with no companion (exit 1): `E8 FAIL E99 - new
  PASS-emitting check E99 ships with no companion mutation entry added to docs/proof-log.md in this PR`.
- Then an entry with an Injected line but no recorded failure: `E8 FAIL E99 - companion entry for E99
  records no observed failure; a companion that never failed proves nothing`. Reverted.

## M-E9 (rule E9)
- Injected: `src/sync/push.ts` fetching a literal host (exit 1): `E9 FAIL src/sync/push.ts:2 - outbound
  network host 'api.salesforce.example.com' is not on the allowlist (which is empty until slice 9)`.
- Then the host assembled from `process.env`: `E9 FAIL src/sync/push.ts:3 - outbound call with an
  unresolved destination; a host the rule cannot read is a host it refuses`. Reverted.

## M-E10 (rule E10)
- Injected: in the clone, one byte of `fixtures/golden/GC-01-firm-a-happy-path.json` changed on a commit
  the oracle ref was pointed at (exit 1, before any parse): `E10 FAIL fixtures/golden/GC-01-...json -
  signed truth changed before parsing: expected sha256 9144263da1c06055c4203248cd6664b3c7666ecb1d4e7b
  9ef69c5abec88bc4ac, read 6fd9f136800692a09288d750500b1caf604d3d5a85577200731c3b9e9f679d75; refusing to
  continue` - both digests printed, no downstream step ran. Reverted: the clone's oracle ref re-fetched.

## M-E11 (rule E11)
The honest-empty tree first reported the required positive result, never skipped:
`E11 report: manifests=0 lockfiles=0 directDependencies=0`. In disposable copies of that tree, each injected
one-sided subject failed naming the subject and the missing proof (exit 1): an empty recognized manifest
(`a dependency manifest appeared with no lockfile; the ratified baseline requires a complete frozen
lockfile`), a lockfile alone (`a lockfile (pnpm-lock.yaml) appeared with no manifest; a partial subject
leaves the honest-empty state and lacks the complete non-empty proof`), and a manifest declaring one
dependency without the baseline (both failures above, subject named). In the separate scratch baseline -
the complete ratified allowlists installed with corepack pnpm 10.15.0, frozen lockfile, all rules
passing before injection - the four non-empty arms each failed: a hand-edited resolved version
(`E11 FAIL react - 'react' is declared 19.2.8 but the lockfile resolves 19.2.9; manifest and lockfile
disagree`, plus the frozen-lockfile install failing); a caret range (`'next' is declared as '^16.3.1', a range; every entry
is an exact version`); an unratified package (`'left-pad' is in neither ratified allowlist; a new package
needs captain ratification`); and `@types/node` moved to a real current non-22 major in manifest and lock
(`the executing Node runtime major is 22 but @types/node is 24.13.3 (major 24); the majors must be
equal` - the runtime side reads `process.versions.node`, not a manifest string). Reverted each time.

## M-E12 (rule E12)
- Injected into the passing baseline: `lodash@4.17.20` (exit 1): `E12 FAIL lodash - 'lodash' 4.17.20
  carries advisory GHSA-35jh-r3h4-6jhm (high), at or above the declared floor` plus four more real advisories from the
  live registry. Then `jszip@3.10.1`: `'jszip' 3.10.1 carries license '(MIT OR GPL-3.0-or-later)', which
  is off the declared allowlist` - every arm of a dual expression must be allowed. Reverted.
- Falsification note: the first baseline run genuinely failed E12 on the ratified set's own transitive
  MPL-2.0 and LGPL-3.0-or-later licenses, and E11 on a pin-parser defect that swallowed sentence-ending
  periods; the declared allowlist was extended by name in CONSTITUTION.md and the parser fixed, in this
  same PR - the rule found two real defects before any mutation was injected.

## M-E13 (rule E13)
- Injected: in a disposable clone, an AWS-key-shaped string committed in `config-creds.js`, then removed
  in a later commit; the shipped scan still failed (exit 1): `E13 FAIL 908e9e8e3785:config-creds.js -
  gitleaks-class rule 'aws-access-key-id' matched a credential-shaped byte in commit 908e9e8e3785, file
  config-creds.js` - the scan reads the whole history, not the tip diff. The injected value was a
  documentation-reserved example key, not a live credential. Reverted with the clone. The pinned
  gitleaks action runs beside this rule in CI as an independent whole-history layer.

## M-E14 (rule E14)
- Injected: a file calling `eval(input)`; the pinned semgrep engine (1.174.0) ran the repo-owned
  `gen4-sast-rules v1` ruleset and the shipped rule failed (exit 1): `E14 FAIL src-probe.mjs:1 - SAST
  rule 'enforcement.gen4-no-eval' (ERROR) matched at src-probe.mjs:1`. With no report present the rule
  fails closed (`no SAST report was provided by the pinned semgrep step (SEMGREP_REPORT); failing
  closed`). Reverted.

## M-E15 (rule E15)
The honest-empty tree first reported the required positive result: `E15 report: releaseArtifacts=0
sbomClaims=0` - never skipped. One-sided subjects injected in disposable copies each failed (exit 1): an artifact
alone (`release artifact 'release/orphan-artifact.tgz' is the subject of no SBOM`) and an SBOM claim
alone (`SBOM 'sbom.cdx.json' names no release subject in this tree (subject: release/nothing.tgz)`). In
the scratch baseline carrying one real packed release artifact and its matching 291-component SBOM (all
rules passing before injection), removing one component failed in one direction
(`E15 FAIL sbom.cdx.json - component 'zod@4.4.3' is in the resolved lockfile but missing from the SBOM`), adding one failed in the other
(`component 'ghost-package@9.9.9' is in the SBOM but the resolved lockfile does not contain it`), and
re-subjecting the SBOM failed both the orphaned artifact and the orphaned claim. Reverted each time.

## M-V2 (rule E15)
- Injected: on the non-empty scratch subject from M-E15, the SBOM's component list replaced with zero
  components (exit 1): `SBOM 'sbom.cdx.json' carries zero components; an empty inventory is the easiest
  false pass and never reports clean`. Reverted. This is the non-empty path, not the honest build-free
  state.

## M-E16 (rule E16)
Subject: a disposable scratch clone carrying the complete ratified baseline, a real `GovernedRuntime` in
TypeScript over a real PostgreSQL client (`pg` 8.23.0 against the pinned `postgres:18.6` image, by digest)
and a real fake provider, a typed seven-row registry spanning all six classes (the class-6 external row
carries an explicit `unreachableInSlice` classification), OpenTelemetry in-memory span and metric capture,
and a real end-to-end test exercising the flow. The happy path passes all six comparisons whole. Every
subcase was injected, observed failing with the exact operation and defect, reverted, and none is caught
by a substring search. Selected exact lines (the full battery transcript is in the PR-1d body):
1. Missing span: `... 'store.insert-account' has 0 completed span(s); exactly one is required (span)`.
2. Missing metric: `... its required metric 'count' recorded a total of 0; exactly once per node is
   required (metric)`. 3. Missing log: `... emitted 0 structured log record(s); ... (log)`.
4. Phantom entry (exit 1): `E16 FAIL store.never-run - registered operation was never exercised and
   carries no unreachableInSlice classification` - the other direction.
5. Source shape is not emission: every emission call left in the source, made unreachable at runtime; the
   source greps clean and E16 still failed all three, because it reads the capture and not the text.
6. Unregistered internal step: unobtainable identity by construction - `tsc` refused all three forcings
   (TS2339 no such gateway entry; TS2339 no generic `enter`; TS2305 the raw interpreter is not exported) -
   and the behavioral relabel failed `exercised operation 'flow.sneaky-read' is absent from the typed
   registry`.
7. Adapter direct-call path: the product-target scan named each raw acquisition at file:line (pg import,
   `new pg.Pool`+`process.env`, `globalThis.fetch`), and the undenied probe failed
   `the start-up probe found 'fetch'/'rawClient' available in the capability-denied product target`.
8. Raw-capability bypass: direct pool work outside the interpreter failed the multiset comparison
   (`invocations count 1 != rawExecutions count 0` naming op, gateway and id); a forged token drew the
   typed refusal naming op, gateway and SemanticEffectId.
9. Semantic-effect smuggling: with every non-semantic field held byte-constant, changing only the SQL
   predicate (and separately only the provider endpoint) refused construction printing both digests
   (`registry digest semfx.v1:9ac7... != constructed digest semfx.v1:4c51...`); two callers of the
   unmodified entry reproduced its one id `semfx.v1:11fb...` in both raw captures.
10. Vacuous/open/misclassified definitions: empty object, truncated validator, unresolved reference,
    generic query form, function-valued constructor and caller-controlled slot each rejected before
    construction naming the closed-language rule; missing fields failed on one row of each effect class
    (store, provider, external); forbidden fields failed on class 1, 2 and 3 rows; a raw effect moved
    under a flow-step failed `no legal multiset row and cannot hide beneath its parent`; empty comparator
    maps beside governed rows failed per-row on the broken bijection, never equality over zero.
11. Missing correlation field: `tsc` refused the wrong kind at the typed entry (TS2345); a parsed value
    forced past the types drew `runtime refusal: correlation for 'decision.record' is missing required
    field 'decisionId'`.
12. False alias: `tsc` refused `RequestId` where `DecisionId` is required (TS2322); forced past the types,
    the purpose tag refused: `field 'decisionId' carries purpose tag 'requestId'; an identifier cannot
    pose as another`. The static sealed-factory fence lands with the runtime it guards in prompt 2.
13. Unsafe emissions: a free-form attribute failed on cardinality against its declared enum domain; a raw
    account reference failed as a PII defect in each of the hyphenated, spaced and bare forms; an ad-hoc
    span name failed `not produced by the declared naming function`.
14. Build tooling in a production bundle: the evidence-tooling import failed the web bundle, then the
    worker bundle, each naming module and bundle; the clean re-run proved both bundles free of it.
- Reverted: every arm was an env-selected mutation in the disposable clone; nothing was promoted, and the
  merged tree gains no line and no dependency from the subject.

## M-V3 (rule E16)
- Injected: a non-empty registry with a capture holding zero telemetry and an empty graph (exit 1):
  `the registry is non-empty but the capture holds zero telemetry and an empty graph; the flow was never
  exercised at all`. A PR that registers no governed operation passes E16 honestly on its empty registry
  delta; a PR that registers one and never ran it does not. Reverted.

## M-V1 (rule E5)
- Injected: a simulated pull request whose base and head are the same commit, so the changed-path list is
  empty (exit 1): `E5 FAIL diff - E5 saw zero changed paths; a check that sees nothing must never report
  clean`. Reverted. A check that sees nothing must never report clean.

## PR-2a proofs (prompt 2 section 6; raw transcripts: docs/evidence/pr2a-transcripts.tar.gz, sha256 e45d4752...)

Every arm below was injected in the working tree, observed failing with the exact line quoted, and
reverted (`git checkout` of the mutated file; the restored tree's green run closes the bundle). None
of these headings names a rule id, deliberately: each rule's one canonical `M-*` entry above stays the
total mapping the runner checks.

### The baseline (spec M-G, rule E11's non-empty path)
1. Caret range: `'next' is declared as '^16.3.1', a range; every entry is an exact version`.
2. Off-allowlist package: `'left-pad' is in neither ratified allowlist; a new package needs captain ratification`.
3. Lockfile deleted: `ERR_PNPM_NO_LOCKFILE  Cannot install with "frozen-lockfile" because pnpm-lock.yaml is absent`.
4. `@types/node` at major 24 under Node 22: `the executing Node runtime major is 22 but @types/node is 24.13.3 (major 24); the majors must be equal`.
5. `NEXT_TELEMETRY_DISABLED` unset under the capability-denied fixture: this Next build attempted no
   telemetry in this environment, and the armed fixture was proven on a real outbound attempt:
   `deny-net: refused outbound tls connect to 'telemetry.nextjs.org' (the external-effect allowlist is
   empty)`; restored, the build completes with zero refusals.

### Sealed authority (spec M-B; the sealed-factory construction rule plus the runtime gateway)
Typed: a cast to `Principal`, a `JSON.parse` fill, casts to `GovernedOperationId` and `RequestId` each
fail the build with file:line (`src/mb-probe.ts:3 casts to sealed type Principal; only its factory may
construct it`, ...); a bare literal fails `tsc` (TS2741, the brand is missing); an unregistered
gateway entry and a generic `enter` fail TS2339. Forced past the types: missing `requestId`, a wrong
purpose tag, a wrong kind, and a structurally valid correlation minted by a second factory are each
refused at the gateway naming the defect (`correlation for 'route.sign-in' was not minted by the
sealed factory; a forged value is refused at the gateway`), and the factory-minted control is accepted.

### The E16 battery against the first real flow (spec M-E, all twelve, plus attributes and naming)
1. Span deleted from sign-in: `operation 'route.sign-in' has 0 completed span(s); exactly one is required (span)`.
2. Metric deleted from the shell's session read: `... its required metric 'count' recorded a total of 0 ... (metric)`.
3. Log deleted from the session-write transaction: `operation 'session.create' emitted 0 structured log record(s) ... (log)`.
4. Phantom row: `registered operation was never exercised and carries no unreachableInSlice classification`.
5. Emissions present in source (grep count 3) but unreachable at runtime: 28 failures - E16 reads the capture, not the text.
6. Unregistered internal step: TS2339 (no entry, no generic `enter`); relabelled in the capture:
   `exercised operation 'flow.sneaky-read' is absent from the typed registry`.
7. Product raw acquisition: `src/app/page.tsx:9 imports the raw database driver directly`, `:10 reads
   the credential environment outside the kernel`, `:11 calls fetch in a product module`; the probe's
   denials stand independently (credential env consumed and deleted by the kernel).
8. Semantic-effect smuggling (only the admitted predicate changed): `refusing construction: registry
   digest semfx.v1:f3ea46e8... != constructed digest semfx.v1:06d0a513...`; two ordinary callers of the
   unmodified entry reproduced one admitted id in both raw captures.
9. Empty, truncated, unresolved, generic, function-valued and caller-controlled definitions each
   refused before construction naming the closed-language rule; the store row stripped of both
   required fields, the fields added to class 1, 2 and 3 rows, a raw execution hidden beneath a
   non-effect parent (`no legal multiset row and cannot hide beneath its parent`), and both definition
   sides emptied all fail per row - never equality over zero.
10. Tampered raw bytes under a kept id: `raw-execution bytes do not reproduce semfx.v1:f3ea46e8...`.
11. Correlation without `requestId`: TS2741 at the typed entry; forced past it: `missing required
    field 'requestId'; the runtime fails closed`.
12. False alias before any second identifier exists: a value with purpose tag `sessionId` in the
    `requestId` slot: `a value cannot pose as another identifier`.
Attributes: an account-shaped `requestId` fails both its digest domain and as a
`hyphenated-account-reference` PII defect; a raw session token, a raw email and a free-form household
name each fail on undeclared value domains (unbounded cardinality). Naming: a concatenated span name
fails `not produced by the declared naming function`.

### The empty capture (spec M-F, vacuity)
With the exercising suite disabled the gate fails, never passes: `the registry is non-empty but the
capture holds zero telemetry and an empty graph; the flow was never exercised at all`.

### The vacuous axe scan (spec M-D)
Pointed at a route that renders nothing, the required loaded-state marker fails first
(`expect(locator).toBeVisible() failed ... element(s) not found`) - an empty render can never pass.

### The two ruled collector sharpenings (GD-002), each with its companion
Owner collector: an over-owner layout still fails (`Canonical owners touched: measured 4 exceeds hard
ceiling 3`) while root bookkeeping files fold into one repository-cluster owner (control clean).
Seam modules: six export lines in the declared seam module fail (`New public seam symbols: measured 6
exceeds hard ceiling 5`); the same lines in an undeclared module measure zero, which is why
`SEAM_MODULES` additions are recorded per slice - the declaration list is the fence.

### The pre-tenant session boundary (5B.2a, this PR's own invariant)
A forged token hash and a tampered cookie signature each resolve to no principal (zero rows under the
session-token GUC policy), proven in the committed suite; the registry carries exactly one operation
with `authorityClass: 'pre-tenant'`. The full section 6 isolation battery with its RLS-dropped
counter-run lands with the tenant tables in PR-2a' and PR-2c.
