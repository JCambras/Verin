// The AccessContext seam (prompt 2 section 4) - the one named contract seam of slice 2, and the home
// of its sealed authority types. Principal, ActionGrant and TenantIdentity are constructible only by
// the factories in this module; the sealed-factory rule in src/tools/e16.test.ts fails the build on a
// cast, a type predicate, an extending interface, or a value filled from any/unknown anywhere else.
// This slice ships authenticate and authorize; withTenant lands with the tenant tables in PR-2a'.
// authenticate takes the request's session cookie value and is read-only: renewal and rotation belong
// to the cookie-writing path and land in PR-2c. The sign-in credential exchange lives here too, as the
// governed route.sign-in use case; passwords are verified with node:crypto scrypt against a per-row
// salt and a constant-time compare (prompt 2 section 5A), burning a compare when the identity is
// unknown so the refusal does not leak which half was wrong.
import { createHash, randomBytes, randomUUID, scryptSync, timingSafeEqual } from "node:crypto";
import { z } from "zod";
import { getGateway, type RequestCorrelation } from "../runtime/governed";

declare const sealed: unique symbol;
type TenantIdentity = { readonly [sealed]: "TenantIdentity"; readonly orgId: string };
type Principal = { readonly [sealed]: "Principal"; readonly identityId: string; readonly displayName: string; readonly role: string; readonly tenant: TenantIdentity };
type ActionGrant = { readonly [sealed]: "ActionGrant"; readonly action: Action; readonly principal: Principal };
export type { Principal, ActionGrant, TenantIdentity };

type Action = "household.read";
const ROLE_ACTIONS: Record<string, readonly Action[]> = { advisor: ["household.read"] };
const sha256 = (s: string) => createHash("sha256").update(s).digest("hex");
const sessionRow = z.strictObject({ identity_id: z.string(), org_id: z.string(), display_name: z.string(), role: z.string(), expires_at: z.date() });
const loginRow = z.strictObject({ id: z.string(), org_id: z.string(), display_name: z.string(), role: z.string(), credential_hash: z.string(), credential_salt: z.string() });

export interface AccessContext {
  authenticate(c: RequestCorrelation, sessionCookie: string | undefined): Promise<Principal | null>;
  authorize(c: RequestCorrelation, principal: Principal, action: Action): Promise<ActionGrant | null>;
}

export function createAccessContext(): AccessContext {
  const gw = getGateway();
  return {
    async authenticate(c, sessionCookie) {
      return gw.enterAccessAuthenticate(c, async () => {
        const token = sessionCookie ? gw.openCookieValue(sessionCookie) : null;
        if (!token) return null;
        const raw = await gw.enterSessionLookupByTokenHash(c, { tokenHash: sha256(token) });
        if (raw === null) return null;
        const s = sessionRow.parse(raw);
        const tenant = { orgId: s.org_id } as TenantIdentity;
        return { identityId: s.identity_id, displayName: s.display_name, role: s.role, tenant } as Principal;
      });
    },
    async authorize(c, principal, action) {
      return gw.enterAccessAuthorize(c, async () =>
        (ROLE_ACTIONS[principal.role] ?? []).includes(action) ? ({ action, principal } as ActionGrant) : null,
      );
    },
  };
}

// The sign-in credential exchange (governed use case route.sign-in). Returns the sealed cookie value
// to set, or null on refusal - one null for every failure shape, timing-flattened.
export async function signIn(c: RequestCorrelation, loginEmail: string, secretText: string): Promise<{ cookieValue: string; expiresAt: Date } | null> {
  const gw = getGateway();
  return gw.enterRouteSignIn(c, async () => {
    const parsed = z.strictObject({ loginEmail: z.email().max(200), secretText: z.string().min(1).max(200) }).safeParse({ loginEmail, secretText });
    if (!parsed.success) return null;
    const raw = await gw.enterIdentityLookupForLogin(c, { loginEmail: parsed.data.loginEmail });
    const id = raw === null ? null : loginRow.parse(raw);
    const derivedKey = scryptSync(parsed.data.secretText, id ? id.credential_salt : "burn-equal-time", 32);
    const stored = id ? Buffer.from(id.credential_hash, "hex") : derivedKey;
    if (id === null || stored.length !== derivedKey.length || !timingSafeEqual(derivedKey, stored)) return null;
    const token = randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 12 * 60 * 60 * 1000);
    await gw.enterSessionCreate(c, { id: randomUUID(), tokenHash: sha256(token), identityId: id.id, orgId: id.org_id, displayName: id.display_name, role: id.role, expiresAt: expiresAt.toISOString() });
    return { cookieValue: gw.sealCookieValue(token), expiresAt };
  });
}
