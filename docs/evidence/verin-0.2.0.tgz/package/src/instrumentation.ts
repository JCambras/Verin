// The web runtime role's composition root (prompt 2 section 3): register() runs once per Next server
// process, so the governed runtime is constructed exactly once here and never re-entered by module
// reloads. The tooling role's composition roots are the entry scripts under src/tools/.
export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    (await import("./runtime/governed")).createGovernedRuntime("web");
  }
}
