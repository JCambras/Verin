import { readFileSync, writeFileSync } from "node:fs";

const [, , arm, mode] = process.argv;
if (!/^arm(?:1|2|5|6|9)$/.test(arm ?? "") || !["apply", "restore"].includes(mode)) {
  throw new Error("usage: node apply-exact-arm.mjs arm{1|2|5|6|9} {apply|restore}");
}

const lines = readFileSync(new URL(`./${arm}-exact-bytes.txt`, import.meta.url), "utf8").split("\n");
const edits = [];
let path = "src/record/decision-record.ts";
let original;
for (const line of lines) {
  if (line.startsWith("file=")) path = line.slice("file=".length);
  if (line.startsWith("exact-original-bytes=")) original = JSON.parse(line.slice("exact-original-bytes=".length));
  if (line.startsWith("exact-mutated-bytes=")) {
    if (original === undefined) throw new Error(`${arm}: mutated bytes have no original bytes`);
    edits.push({ path, original, mutated: JSON.parse(line.slice("exact-mutated-bytes=".length)) });
    original = undefined;
  }
}
if (edits.length === 0) throw new Error(`${arm}: no exact edits parsed`);

const ordered = mode === "apply" ? edits : edits.toReversed();
for (const edit of ordered) {
  const before = mode === "apply" ? edit.original : edit.mutated;
  const after = mode === "apply" ? edit.mutated : edit.original;
  const source = readFileSync(edit.path, "utf8");
  if (source.split(before).length !== 2) throw new Error(`${arm}: expected bytes not found exactly once in ${edit.path}`);
  writeFileSync(edit.path, source.replace(before, after));
  console.log(`file=${edit.path}`);
  console.log(`exact-original-bytes=${JSON.stringify(edit.original)}`);
  console.log(`exact-mutated-bytes=${JSON.stringify(edit.mutated)}`);
}
