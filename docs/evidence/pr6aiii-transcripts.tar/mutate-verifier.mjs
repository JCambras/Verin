import { copyFileSync, readFileSync, writeFileSync } from "node:fs";

const mode = process.argv[2];
const path = "src/record/decision-record.ts";
const backup = `test-results/pr6aiii-evidence/decision-record-${mode}.backup`;
copyFileSync(path, backup);
const source = readFileSync(path, "utf8");
let before;
let after;
if (mode === "property") {
  before = `    async verify() {\n      return (await verifyStoredChain(c, grant)).verification;\n    },`;
  after = `    async verify() {\n      return { ok: true, through: decisionId, entryCount: 1, headHash: "dlh.v1:${"0".repeat(64)}", continuityManifest: "lcm.v1:${"0".repeat(64)}", rebuiltProjection: [] };\n    },`;
} else if (mode === "early-return") {
  before = `async function verifyStoredChain(c: DecisionCorrelation, grant: ActionGrant): Promise<{ verification: ChainVerification; records: Map<string, VerifiedParts> }> {\n`;
  after = `${before}  if (String(1) === "1") return { verification: { ok: true, through: \`d\${c.fields.decisionId.value}\`, entryCount: 0, headHash: \`dlh.v1:\${"0".repeat(64)}\`, continuityManifest: \`lcm.v1:\${"0".repeat(64)}\`, rebuiltProjection: [] }, records: new Map<string, VerifiedParts>() };\n`;
} else {
  throw new Error(`unknown verifier mutation '${mode}'`);
}
if (source.split(before).length !== 2) throw new Error(`${mode} subject was not found exactly once`);
writeFileSync(path, source.replace(before, after));
console.log(`exact-original-bytes=${JSON.stringify(before)}`);
console.log(`exact-mutated-bytes=${JSON.stringify(after)}`);
console.log(`backup=${backup}`);
