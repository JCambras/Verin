# Operative result summary

| Arm | Injected defect | Clean before | Mutated command | Clean after |
| --- | --- | --- | --- | --- |
| 1 | public verify property returns unconditional success | PASS | FAIL, exit 1 | PASS |
| 2 | whole-chain verifier returns unconditional success before its body | PASS | FAIL, exit 1 | PASS |
| 5 | ledger digests omit the genesis continuity citation | PASS | FAIL, exit 1 | PASS |
| 6 | integrity checks run only for test-produced entries | PASS | FAIL, exit 1 | PASS |
| 9 | entry identity and chain-hash content comparisons are disabled | PASS | FAIL, exit 1 | PASS |

The workflow slice control passes 65 instrumented tests, one independent verifier test and five
closure tests, with an empty porcelain status both before and after.

The final local control also passes the committed format rule, lint, capability-denied build and all
22 browser tests with an empty porcelain status at both ends.
