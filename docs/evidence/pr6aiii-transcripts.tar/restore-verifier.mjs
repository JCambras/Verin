import { copyFileSync } from "node:fs";

const mode = process.argv[2];
copyFileSync(`test-results/pr6aiii-evidence/decision-record-${mode}.backup`, "src/record/decision-record.ts");
console.log(`restored=${mode}`);
