# PR-6a-iii corrected verifier evidence

Operative product head: `9dc3b35e3cc65fea47795c2b89c316246bd5413d`.

The independent command now records one real decision through the public runtime, rewrites the
genesis `continuityManifest` to a same-length lcm.v1 identity while retaining valid JSON, and requires
public `DecisionRecord.verify()` to return `payload-rewritten` at sequence 0. It then restores the
exact envelope, changes only the stored genesis chain hash, and requires
`entry-hash-mismatch` at sequence 0. The fixture is tooling-produced so an implementation that checks
only test-produced entries cannot satisfy the assertion.

## Operative controls and arms

For each of arms 1, 2, 5, 6 and 9:

- `armN-pre-control.txt` records the exact product head, an empty porcelain status and a passing
  `corepack pnpm test:decision-record-verifier` control.
- `armN-exact-bytes.txt` and `armN-applied.txt` record the exact original and injected bytes.
- `armN-mutated.txt` records the nonzero assertion failure from the public verifier command.
- `armN-restored.txt` records the exact inverse edit.
- `armN-post-control.txt` records the second empty porcelain status and passing restored command.

Arms 1 and 2 are the previously ruled public-property and total-early-return stubs. Arms 5, 6 and 9
are the independent pass's exact citation-blind digest, test-producer-only integrity and deleted
content-binding hollowings. Every mutated command exits 1 because it receives an accepted result
where the public assertion requires the named refusal.

`workflow-slice-control.txt` records the committed workflow order and a clean run of the three
consecutive local commands: the 65-test instrumented suite, the one-test verifier companion and the
five-test closure suite. The verifier command is now an explicit blocking step between the other two.

`additional-local-controls.txt` records the clean evidence-head controls for the committed format
rule, lint, the capability-denied production build and all 22 browser tests. The browser run includes
the examiner loaded-state Axe assertion.

The PostgreSQL subject was the lane-owned `verin-p6aiii-verifier` container on host port 55683. No
default database port was used.

## Historical material

`HISTORICAL-prior-bundle.tar` is the earlier 18f2ff29 evidence bundle, retained only to make
supersession explicit. Its two named-stub runs remain historical context and are not cited for the
corrected product head. The operative records are the controls and arms listed above.

`HISTORICAL-overbroad-format-control.txt` records a first attempt that asked Prettier to check Markdown
outside the repository's committed format rule and therefore failed clean. It is historical and is not
cited as a control. The operative replacement is the passing `corepack pnpm format` invocation in
`additional-local-controls.txt`.
