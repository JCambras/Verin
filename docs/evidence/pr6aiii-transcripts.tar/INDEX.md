# PR-6a-iii evidence index

All paths below are relative to this evidence directory. The separately invocable command is
`corepack pnpm test:decision-record-verifier`; every mutation arm runs that exact command on the
unmutated committed product head first, records the exact injected bytes, observes the public-seam
assertion fail, restores the source, and observes the same command pass again.

- `product-head.txt` - exact committed product head for the captures.
- `property-clean-control.txt` - operative clean control, PASS.
- `property-exact-bytes.txt` - exact public `verify()` original and `ok: true` replacement bytes.
- `property-mutated-failure.txt` - operative mutation, FAIL on the damaged-chain refusal assertion.
- `property-restore.txt` and `property-restored-control.txt` - exact restore and PASS.
- `early-return-clean-control.txt` - operative clean control, PASS.
- `early-return-exact-bytes.txt` - exact early-return insertion ahead of the intact verifier body.
- `early-return-mutated-failure.txt` - operative mutation, FAIL on the damaged-chain refusal assertion.
- `early-return-restore.txt` and `early-return-restored-control.txt` - exact restore and PASS.
- `e2e-clean-control.txt` - 22 browser tests PASS, including Axe on the examiner loaded state and the
  refreshed full-page capture.
- `mutate-verifier.mjs`, `restore-verifier.mjs` and both `.backup` files - exact reproducibility and
  restore subjects for the two operative mutation arms.

There are no superseded runs in this bundle.
