# PR-6-pre evidence index

Battery head: `2c6da91c30fd44eb580c050b40694f582a9243bd`

- `typed-value-control-operative.txt` - operative clean-tree control. The exact full-file command
  passes 55/55 before any mutation.
- `typed-value-mutation-operative.txt` - operative mutation. It records the exact source diff that
  changes GC-01's signed typed `trigger.amountUsd` value from 75,000 to 76,000, then the same full-file
  command fails 4/55. The first failure names the signed and produced idempotency keys.
- `typed-value-restored.txt` - exact mutation reverted, clean tree restored, same command passes 55/55.
- `db-operative-control.txt` - pinned Postgres 18.6 digest, owned container, non-default host port
  55561, bootstrap, migration, and seed used by the operative control.
- `green-restored.txt` - CI-ordered restored run: pinned Semgrep, frozen install, lint, format, migrate
  twice, seed, full 60-test suite, explicit five-test closure suite, capability-denied build, and all 21
  browser tests.
- `artifact-reproduction-operative.txt` - clean-tree regeneration: conformance SHA-256
  `714625944c6550d8c289f479128ddfec834e7e0ceefba6a76a7f628b380c631d`, replay-manifest SHA-256
  `f961119ccb9e99e31a2e10923e3d3273ecaaa326a56256cfa4e16fc64a7d664d`, totals 210/4/28,
  four ledger entries, 16 cases, and 119 consumed signed typed quantities.
- `pr6pre-conformance.png` - Playwright full-page capture after URL and loaded-state assertions. The
  page shows all 16 cases and labels every case as reading load-bearing quantities directly from signed
  typed rows, with summary prose excluded from inputs.
- `HISTORICAL-control-missing-super-url.txt` and `db-control.txt` - HISTORICAL, not evidence for any
  claim. The initial test environment omitted the superuser URL required by child checks, so eight tests
  fell back to port 5432 and failed before the operative control above replaced it.
- `HISTORICAL-artifact-stats-path.txt` - HISTORICAL, not evidence for the count claim. Both artifact
  hashes reproduced, but the final statistics expression addressed an obsolete JSON path. The operative
  transcript above replaces it and completes all statistics.

No transcript contains database URLs, database passwords, or cookie-signing values.
