import { readFileSync, writeFileSync } from "node:fs";

const [arm, path] = process.argv.slice(2);
const capture = JSON.parse(readFileSync(path, "utf8"));
const record = "decisionRecord.record";
const append = "decisionRecord.append";
let mutation;

const removeEmission = (op, kind) => {
  if (kind === "metric") {
    const name = `verin.op.${op}.count`;
    const index = capture.emissions.metrics.findIndex((entry) => entry.name === name);
    const before = structuredClone(capture.emissions.metrics[index]);
    if (before.value > 1) capture.emissions.metrics[index].value -= 1;
    else capture.emissions.metrics.splice(index, 1);
    return { path: `emissions.metrics[${index}]`, before, after: before.value > 1 ? capture.emissions.metrics[index] : "deleted" };
  }
  const node = capture.graph.find((entry) => entry.op === op).node;
  const list = capture.emissions[`${kind}s`];
  const index = list.findIndex((entry) => entry.node === node);
  return { path: `emissions.${kind}s[${index}]`, before: list.splice(index, 1)[0], after: "deleted" };
};

if (/^(record|append)-(span|log|metric)$/.test(arm)) {
  const [, op, kind] = arm.match(/^(record|append)-(span|log|metric)$/);
  mutation = removeEmission(op === "record" ? record : append, kind);
} else if (arm === "unregistered") {
  const before = capture.graph.find((entry) => entry.op === record);
  const after = { ...structuredClone(before), node: "mutation-unregistered-node", op: "decisionRecord.unregistered" };
  capture.graph.push(after);
  mutation = { path: "graph[+]", before: "absent", after };
} else if (arm === "unexercised") {
  const sourceRegistry = capture.registry.find((entry) => entry.id === record);
  const sourceAdmission = capture.admission.find((entry) => entry.id === record);
  const row = { ...structuredClone(sourceRegistry), id: "decisionRecord.unexercised", gatewayEntry: "enterDecisionRecordUnexercised" };
  const admission = { ...structuredClone(sourceAdmission), id: row.id, gatewayEntry: row.gatewayEntry };
  capture.registry.push(row);
  capture.admission.push(admission);
  mutation = { path: "registry[+],admission[+]", before: "absent", after: { row, admission } };
} else if (arm === "unreachable-emission") {
  const index = capture.graph.findIndex((entry) => entry.op === record);
  mutation = { path: `graph[${index}]`, before: capture.graph.splice(index, 1)[0], after: "deleted while its emissions remain" };
} else if (arm === "bypass") {
  const index = capture.rawExecutions.findIndex((entry) => entry.op === append);
  mutation = { path: `rawExecutions[${index}]`, before: capture.rawExecutions.splice(index, 1)[0], after: "deleted" };
} else if (arm === "borrow-id") {
  const target = capture.rawExecutions.find((entry) => entry.op === append);
  const borrowed = capture.registry.find((entry) => entry.id === "policy.appendVersion").semanticEffectId;
  mutation = { path: "rawExecutions[decisionRecord.append].semanticEffectId", before: target.semanticEffectId, after: borrowed };
  target.semanticEffectId = borrowed;
} else if (arm === "registry-definition") {
  const target = capture.registry.find((entry) => entry.id === append).semanticEffect;
  mutation = { path: "registry[decisionRecord.append].semanticEffect.command", before: target.command, after: "decision-record-append.mutated" };
  target.command = mutation.after;
} else if (arm === "admission-definition") {
  const target = capture.admission.find((entry) => entry.id === append).constructedDefinition;
  mutation = { path: "admission[decisionRecord.append].constructedDefinition.command", before: target.command, after: "decision-record-append.mutated" };
  target.command = mutation.after;
} else if (arm === "record-correlation" || arm === "append-correlation") {
  const op = arm === "record-correlation" ? record : append;
  const target = capture.graph.find((entry) => entry.op === op).correlation;
  mutation = { path: `graph[${op}].correlation`, before: structuredClone(target), after: { kind: "RequestCorrelation", fields: { requestId: target.fields.requestId } } };
  Object.assign(target, mutation.after);
} else {
  throw new Error(`unknown arm ${arm}`);
}

writeFileSync(path, JSON.stringify(capture, null, 1));
console.log(`arm=${arm}`);
console.log(JSON.stringify(mutation, null, 2));
