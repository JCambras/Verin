#!/bin/sh
set -u

arm="$1"
capture="test-results/pr6ai-evidence/e16-capture.json"
subject="test-results/pr6ai-evidence/arm.json"
checker="E16_EVIDENCE=$subject node test-results/pr6ai-evidence/check-e16.mjs"

echo "arm=$arm"
echo "head=$(git rev-parse HEAD)"
echo "status-begin"
git status --porcelain
echo "status-end"
cp "$capture" "$subject"
echo "control-command=$checker"
E16_EVIDENCE="$subject" node test-results/pr6ai-evidence/check-e16.mjs
control_exit=$?
echo "control-exit=$control_exit"
node test-results/pr6ai-evidence/mutate-e16.mjs "$arm" "$subject"
echo "mutation-command=$checker"
E16_EVIDENCE="$subject" node test-results/pr6ai-evidence/check-e16.mjs
mutation_exit=$?
echo "mutation-exit=$mutation_exit"
cp "$capture" "$subject"
echo "restore-command=$checker"
E16_EVIDENCE="$subject" node test-results/pr6ai-evidence/check-e16.mjs
restore_exit=$?
echo "restore-exit=$restore_exit"
echo "status-begin"
git status --porcelain
echo "status-end"
test "$control_exit" -eq 0 && test "$mutation_exit" -ne 0 && test "$restore_exit" -eq 0
