#!/bin/sh
set -eu

echo "base=$(git rev-parse origin/generation-4)"
echo "head=$(git rev-parse HEAD)"
echo "status-begin"
git status --porcelain
echo "status-end"
SEMGREP_REPORT=test-results/semgrep-report.json E16_EVIDENCE=test-results/pr6ai-evidence/e16-capture.json node --input-type=module - "$(git rev-parse HEAD)" <<'EOF'
import { readFileSync } from "node:fs";
import { collectTreeFacts } from "./enforcement/rules-tree.mjs";
import { collectSupplyFacts } from "./enforcement/rules-supply.mjs";
import { evaluateEnforcement, RULES } from "./enforcement/contract.mjs";

const base = "72f69161aca9ee28506735357c2e3f266e84989a";
const head = process.argv[2];
const section = readFileSync("CONSTITUTION.md", "utf8").split(/^## The ten-slice roadmap.*$/m)[1]?.split(/^## /m)[0] ?? "";
const collected = {
  eventName: "pull_request",
  baseRef: "generation-4",
  headRef: "fm/verin-gen4-p6-ledger",
  baseSha: base,
  headSha: head,
  mergeBaseWithMain: [],
  defaultBranch: "main",
  declaredSeamIds: ["DecisionRecord"],
  declaredSliceClass: "core-semantics/record",
  roadmapSeamIds: [...section.matchAll(/^\| \d+ \| \d+ \| `([A-Za-z0-9]+)` \|/gm)].map((match) => match[1]),
};
const report = evaluateEnforcement({ ...collected, ...collectTreeFacts(collected), ...collectSupplyFacts() });
for (const id of RULES.keys()) console.log(report.violations.some((problem) => problem.rule === id) ? `${id} FAIL` : `${id} PASS`);
for (const problem of report.violations) console.log(`${problem.rule} FAIL ${problem.ref} - ${problem.message}`);
process.exitCode = report.violations.length ? 1 : 0;
EOF
echo "status-begin"
git status --porcelain
echo "status-end"
