#!/bin/sh
set -eu

echo "head=$(git rev-parse HEAD)"
echo "status-begin"
git status --porcelain
echo "status-end"
echo "exact-fix"
git show --format=fuller --stat --patch HEAD
export APP_ENV=test
export VERIN_SUPER_DATABASE_URL=postgresql://postgres:postgres@localhost:55681/postgres
export VERIN_MIGRATOR_DATABASE_URL=postgresql://verin_migrator:verin-migrator-local@localhost:55681/verin
export VERIN_APP_DATABASE_URL=postgresql://verin_app:verin-app-local@localhost:55681/verin
export VERIN_COOKIE_KEY=p6a-test-cookie-key
echo "command=corepack pnpm exec playwright test src/e2e/app.e2e.ts:45 --repeat-each=20 --workers=1"
corepack pnpm exec playwright test src/e2e/app.e2e.ts:45 --repeat-each=20 --workers=1
echo "status-begin"
git status --porcelain
echo "status-end"
