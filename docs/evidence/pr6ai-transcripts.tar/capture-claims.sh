#!/bin/sh
set -eu

echo "base=$(git rev-parse origin/generation-4)"
echo "head=$(git rev-parse HEAD)"
echo "origin-main=$(git rev-parse origin/main)"
echo "status-begin"
git status --porcelain
echo "status-end"

echo "prompt-5-close-is-ancestor"
git merge-base --is-ancestor 52a22fdc origin/generation-4
echo "$?"
echo "signed-amendment-is-origin-main"
test "$(git rev-parse origin/main)" = 5542c99989fc7cec0b6e94851797b6ca3ad490a9
echo "$?"
echo "merged-prerequisite-head"
git show -s --format='%H %s' origin/generation-4
echo "signed-pins"
jq '{oracleHead, pinCount:(.pins|length)}' enforcement/signed-truth-pins.json
node --input-type=module -e 'import {collectTreeFacts,e10SignedTruthImmutable} from "./enforcement/rules-tree.mjs"; const f=collectTreeFacts({eventName:"pull_request",baseSha:"72f69161aca9ee28506735357c2e3f266e84989a",headSha:process.argv[1]}); const v=e10SignedTruthImmutable(f); console.log(v.length ? v : "E10 PASS"); process.exitCode=v.length?1:0' "$(git rev-parse HEAD)"

echo "generated-engine-control"
corepack pnpm exec tsx src/tools/decision-engine-identity.ts --print | cmp - src/decision/engine-identity.json
echo "engine-identity-byte-compare=PASS"
echo "new-operation-capture"
jq '{registry:[.registry[]|select(.id=="decisionRecord.record" or .id=="decisionRecord.append")],admission:[.admission[]|select(.id=="decisionRecord.record" or .id=="decisionRecord.append")],correlationTable:{"decisionRecord.record":.correlationTable["decisionRecord.record"],"decisionRecord.append":.correlationTable["decisionRecord.append"]},graphCounts:(.graph|group_by(.op)|map({op:.[0].op,count:length})|map(select(.op=="decisionRecord.record" or .op=="decisionRecord.append"))),invocationCounts:(.invocations|group_by(.op)|map({op:.[0].op,count:length})|map(select(.op=="decisionRecord.append"))),rawExecutionCounts:(.rawExecutions|group_by(.op)|map({op:.[0].op,count:length})|map(select(.op=="decisionRecord.append")))}' test-results/pr6ai-evidence/e16-capture.json

echo "exact-committed-battery-source"
sed -n '585,765p' src/tools/e16.test.ts
echo "exact-committed-migration"
git show HEAD:src/store/migrations/007-decision-record.sql

echo "application-role-privileges"
docker exec verin-p6a-record psql -U postgres -d verin -v ON_ERROR_STOP=1 -c "SELECT table_name, string_agg(privilege_type, ',' ORDER BY privilege_type) privileges FROM information_schema.role_table_grants WHERE grantee='verin_app' AND table_name LIKE 'decision_%' GROUP BY table_name ORDER BY table_name"
echo "immutability-triggers"
docker exec verin-p6a-record psql -U postgres -d verin -v ON_ERROR_STOP=1 -c "SELECT c.relname table_name, t.tgname trigger_name FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid WHERE NOT t.tgisinternal AND c.relname IN ('decision_continuity_authorization','decision_record_source','decision_ledger') ORDER BY c.relname,t.tgname"
echo "post-battery-chain-state"
docker exec verin-p6a-record psql -U postgres -d verin -v ON_ERROR_STOP=1 -c "SELECT o.name, count(l.seq) entries, min(l.seq) min_seq, max(l.seq) max_seq, a.entry_count, a.max_seq anchor_max_seq, a.head_hash=hl.entry_hash head_matches FROM org o JOIN decision_chain_anchor a ON a.org_id=o.id JOIN decision_ledger hl ON hl.org_id=o.id AND hl.seq=a.max_seq JOIN decision_ledger l ON l.org_id=o.id GROUP BY o.name,a.entry_count,a.max_seq,a.head_hash,hl.entry_hash ORDER BY o.name"
docker exec verin-p6a-record psql -U postgres -d verin -v ON_ERROR_STOP=1 -c "SELECT count(*) broken_links FROM decision_ledger l LEFT JOIN decision_ledger p ON p.org_id=l.org_id AND p.seq=l.seq-1 WHERE l.seq>0 AND (p.entry_hash IS NULL OR l.prev_hash<>p.entry_hash)"
echo "status-begin"
git status --porcelain
echo "status-end"
