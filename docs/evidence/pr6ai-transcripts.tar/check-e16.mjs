import { e16GovernedRuntimeObservability } from "../../enforcement/rules-e16.mjs";

const violations = e16GovernedRuntimeObservability();
if (violations.length === 0) {
  console.log("E16 PASS");
} else {
  console.log("E16 FAIL");
  for (const problem of violations) console.log(`${problem.rule} FAIL ${problem.ref} - ${problem.message}`);
  process.exitCode = 1;
}
