# PR-6a-i evidence index

Scope: the bounded atomic-record half of PR-6a. It lands canonical DecisionRecord source and envelope bytes, the five-table migration, two append-only barriers, exactly one governed `decisionRecord.append` closed-store-command, the `decisionRecord.record` seam operation, concurrency and rollback batteries, and the reachable recorded state on the existing decision surface.

The skeleton measurement crossed the hard ceilings, so the stack moved from 37 to 38 program units. PR-6a-ii owns pre-identity list/head reads, the RequestCorrelation-to-DecisionCorrelation transition, load, whole-chain and anchor verification, projection rebuild, temporal read normalization, and the examiner record surface. PR-6b still owns replay and conformance. PR-6c still owns the product-owner-authorized continuity boundary. This bundle makes no claim for those later obligations.

## Exact heads and store

- Base: `72f69161aca9ee28506735357c2e3f266e84989a`.
- Implementation/control head: `9193341f8a1e58e940ebf706ed685c3089b1b22b`.
- Evidence-indexed head: `42553d6b9b9f996482c30264e27e07036ffd81b7`.
- Read-only oracle head: `5542c99989fc7cec0b6e94851797b6ca3ad490a9`.
- Dedicated container: `postgres:18.6@sha256:06cad38a5d9f5d24b4d83d86def30795d5e4b757fedbf5281172b576dedcd941` on host port `55681`, never the default port.
- `green-control.txt` begins and ends with an empty tracked status and records the exact container id.

## Operative records

- `green-control.txt` - fresh container; bootstrap, migrate, migrate idempotence, seed, lint, format, 63 tests, the five-test pure closure, denied-network production build, 21 browser tests with Axe, generated engine byte comparison, and clean E16 control. The recorded decision screenshot is captured by that browser run at this head.
- `claims.txt` - Prompt 5 ancestry, exact signed-pin oracle, E10, byte-identical engine regeneration, both new E16 rows and their registry/admission/correlation/graph/invocation/raw-execution facts, exact committed battery and migration bytes, application privileges, owner triggers, anchor/head agreement, and zero broken links.
- `enforcement-final.txt` - the committed collector and supply checks at the evidence-indexed head: E1 through E16 all PASS, with empty tracked status before and after.
- `e16-capture.json` - the complete governed runtime capture emitted by the operative clean run.
- `e16-*.txt` - fifteen independent arms. Every file records an empty clean status, a passing control, exact mutated capture bytes, failure from the same checker command, restoration, another pass, and an empty status. The arms remove span, log, and metric emissions from each new operation; add unregistered and unexercised rows; disconnect an emission; remove a raw command execution; borrow another semantic identity; change the registry and admission definitions separately; and put RequestCorrelation on each DecisionCorrelation row.
- `pr6ai-decide-recorded.png` - 1280x800 browser capture after the loaded marker and atomic-record assertions, SHA-256 `02a00f95b1ce4ad0ec82981a789341d2e05f6a4ebdb7b8a9d6b77a86d8832b9c`.
- `screen-inspection.txt` - dimensions, hash, Axe result, and visual inspection notes for that capture.
- `check-e16.mjs`, `mutate-e16.mjs`, `run-e16-arm.sh`, `run-green-control.sh`, `run-enforcement.sh`, and `capture-claims.sh` - exact reproduction tools used for the records above.

## Historical record

- `HISTORICAL-claims-wrong-full-sha.txt` - superseded prerequisite attempt. It stopped before any later claim after expanding the known short oracle id to the wrong full SHA. `claims.txt` is the operative replacement and reads the exact fetched SHA before checking it.

## Claim boundary

The application role lacks UPDATE and DELETE on authoritative rows, while owner-level UPDATE, DELETE, and TRUNCATE hit dedicated triggers. A fully privileged database actor can disable those guards. PR-6a-ii adds whole-chain verification so the slice can claim TAMPER EVIDENCE inside the ratified threat boundary. This unit does not claim absolute protection and does not claim an authenticated latest-head anchor outside the database.

The continuity rows used here are explicit test fixtures. Their bytes state that they are not a product signature, and no product authorization is claimed or performed in this unit.
