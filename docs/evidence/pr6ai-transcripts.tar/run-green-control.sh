#!/bin/sh
set -eu

echo "base=$(git rev-parse origin/generation-4)"
echo "head=$(git rev-parse HEAD)"
echo "branch=$(git branch --show-current)"
echo "origin-main=$(git rev-parse origin/main)"
echo "merge-base-with-main-begin"
git merge-base --all HEAD origin/main || true
echo "merge-base-with-main-end"
echo "status-begin"
git status --porcelain
echo "status-end"

docker rm -f verin-p6a-record
docker run --name verin-p6a-record -e POSTGRES_PASSWORD=postgres -p 55681:5432 -d postgres:18.6@sha256:06cad38a5d9f5d24b4d83d86def30795d5e4b757fedbf5281172b576dedcd941
until docker exec verin-p6a-record pg_isready -U postgres; do :; done
docker inspect verin-p6a-record --format 'container={{.Id}} image={{.Image}} ports={{json .NetworkSettings.Ports}}'

export APP_ENV=test
export VERIN_SUPER_DATABASE_URL=postgresql://postgres:postgres@localhost:55681/postgres
export VERIN_MIGRATOR_DATABASE_URL=postgresql://verin_migrator:verin-migrator-local@localhost:55681/verin
export VERIN_APP_DATABASE_URL=postgresql://verin_app:verin-app-local@localhost:55681/verin
export VERIN_COOKIE_KEY=p6a-test-cookie-key
export E16_EVIDENCE=test-results/e16-capture.json

corepack pnpm exec tsx src/tools/cli.ts bootstrap
corepack pnpm exec tsx src/tools/cli.ts migrate
corepack pnpm exec tsx src/tools/cli.ts migrate
corepack pnpm exec tsx src/tools/cli.ts seed
corepack pnpm lint
corepack pnpm format
corepack pnpm test
corepack pnpm exec vitest run src/tools/decision-closure.test.ts
NODE_OPTIONS="--require ./src/tools/deny-net.cjs" corepack pnpm build
corepack pnpm e2e
corepack pnpm exec tsx src/tools/decision-engine-identity.ts --print | cmp - src/decision/engine-identity.json
cp test-results/e16-capture.json test-results/pr6ai-evidence/e16-capture.json
E16_EVIDENCE=test-results/pr6ai-evidence/e16-capture.json node test-results/pr6ai-evidence/check-e16.mjs
echo "status-begin"
git status --porcelain
echo "status-end"
